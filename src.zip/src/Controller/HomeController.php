<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class HomeController extends AbstractController
{
    #[Route('/', name: 'app_home', methods: ['GET'])]
    public function index(): Response
    {
        $featuredProducts = [
            [
                'name' => 'Spanish Latte',
                'description' => 'A smooth espresso blended with creamy milk and a touch of sweetness.',
                'price' => '₱120',
                'image' => 'images/home/featured-spanish-latte.jpg',
                'category' => 'BEST SELLER',
            ],
            [
                'name' => 'Matcha Latte',
                'description' => 'A refreshing combination of earthy matcha and creamy milk.',
                'price' => '₱130',
                'image' => 'images/home/featured-matcha.jpg',
                'category' => 'CUSTOMER FAVORITE',
            ],
            [
                'name' => 'Mocha',
                'description' => 'Rich chocolate and espresso blended into one comforting cup.',
                'price' => '₱125',
                'image' => 'images/home/featured-mocha.jpg',
                'category' => 'MUST TRY',
            ],
        ];

        return $this->render('home/index.html.twig', [
            'featuredProducts' => $featuredProducts,
            'location' => 'G. Tolentino Street, Sampaloc, Manila, Philippines',
            'businessName' => 'every cup.',
        ]);

    }

    #[Route('/delivery', name: 'app_delivery')]
    public function delivery(): Response
    {
        return $this->render('home/delivery.html.twig');
    }

    #[Route('/contact', name: 'app_contact')]
    public function contact(): Response
    {
        return $this->render('home/contact.html.twig');
    }

    #[Route('/faq', name: 'app_faq')]
    public function faq(): Response
    {
        return $this->render('home/faq.html.twig');
    }
}